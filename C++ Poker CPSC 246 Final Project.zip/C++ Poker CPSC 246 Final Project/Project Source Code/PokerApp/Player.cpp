#include "pch.h"
#include "Player.h"
#include <iostream>
#include "Deck.h"

using namespace std;

Player::Player()
{
	isTurn = isFold = bigBlind = smallBlind = dealer = false;
	isPlayer = true;
	betAmount = 0;
}

Player::Player(Deck* d)
{
	bigBlind = smallBlind = dealer = isFold = isTurn = false;
	isPlayer = true;
	playerHand = Hand(d);
	betAmount = 0;
}

Player::~Player()
{
}

void Player::setName(string pName)
{
	name = pName;
}

string Player::getName()
{
	return name;
}

string Player::giveName()
{
	return botName;
}

int Player::setBetAmount(int bet)
{
	betAmount = bet;
	return betAmount;
}

int Player::getBetAmount()
{
	return betAmount;
}

bool Player::toggleBigBlind()
{
	bigBlind = !bigBlind;
	return bigBlind;
}

bool Player::toggleSmallBlind()
{
	smallBlind = !smallBlind;
	return smallBlind;
}

bool Player::toggleDealer()
{
	dealer = !dealer;
	return dealer;
}

bool Player::getBigBlind()
{
	return bigBlind;
}

bool Player::getSmallBlind()
{
	return smallBlind;
}

bool Player::getDealer()
{
	return dealer;
}

bool Player::toggleIsTurn()
{
	isTurn = !isTurn;
	return isTurn;
}

bool Player::toggleIsFold()
{
	isFold = !isFold;
	return isFold;
}

bool Player::getFolded()
{
	return isFold;
}

bool Player::toggleIsPlayer()
{
	isPlayer = !isPlayer;
	return isPlayer;
}

bool Player::getIsPlayer() { return isPlayer; }

void Player::drawCard()
{
	playerHand.drawCard();
}

void Player::placeBet(int amt)
{
	playerBal.removeBalance(amt);
}

void Player::addSharedCard(Card card)
{
	playerHand.addCard(card);
}

Card Player::getCard(int index)
{
	return playerHand.getCard(index);
}

void Player::clearHand()
{
	playerHand.clearHand();
}

void Player::call(int betAmount)
{
	placeBet(betAmount);
}
void Player::winBet(int amt)
{
	playerBal.addBalance(amt);
}

void Player::printHand()
{
	playerHand.PrintPlayerHand();
}

int Player::calcHandVal()
{
	handValue = playerHand.calcHandVal();

	return handValue;
}