#include "pch.h"
#include "Bot.h"


Bot::Bot()
{
	bigBlind = false;
	smallBlind = false;
	dealer = false;
	isPlayer = false;
	betAmount = 0;
}

Bot::Bot(Deck* d)
{
	bigBlind = false;
	smallBlind = false;
	dealer = false;
	isPlayer = false;
	botHand = Hand(d);
}


Bot::~Bot()
{
}


int Bot::fold(){return 3;}
int Bot::call() { return 1; }

void Bot::setPersonality()
{
	switch (rand() % 4)
	{
	case 0:
		loosePassive = true;
		isLoosePassive();
		break;
	case 1:
		looseAggressive = true;
		isLooseAggressive();
		break;
	case 2:
		tightAggressive = true;
		isTightAggressive();
		break;
	case 3:
		tightPassive = true;
		isTightAggressive();
		break;
	}
}

void Bot::isLoosePassive()
{
	if (botHand.calcHandVal() < 1000) //make the value something relatively high
	{
		placeBet(500);
		
	
	}
}

void Bot::isLooseAggressive()
{
	if (botHand.calcHandVal() < 1000)
	{
		//actions for loose passive? idk i don't play poker
	}
}

void Bot::isTightAggressive()
{
	if (botHand.calcHandVal() < 1000)
	{
		//actions for loose passive? idk i don't play poker
	}
}

void Bot::isTightPassive()
{
	if (botHand.calcHandVal() < 1000)
	{
		//actions for loose passive? idk i don't play poker
	}
}
