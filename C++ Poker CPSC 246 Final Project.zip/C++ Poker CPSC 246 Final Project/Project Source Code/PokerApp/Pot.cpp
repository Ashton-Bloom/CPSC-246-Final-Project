#include "pch.h"
#include "Pot.h"


Pot::Pot()
{
	potAmount = 0;
}


Pot::~Pot()
{
}

void Pot::addAmt(int bet)
{
	potAmount += bet;
}

void Pot::resetPot()
{
	potAmount = 0;
}

int Pot::getPot()
{
	return potAmount;
}
