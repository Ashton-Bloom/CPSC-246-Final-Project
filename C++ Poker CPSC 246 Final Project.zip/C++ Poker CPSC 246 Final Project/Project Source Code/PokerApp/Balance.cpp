#include "pch.h"
#include "Balance.h"


Balance::Balance()
{
	amount = 1000;
}


Balance::~Balance()
{
}

void Balance::addBalance(int addAmt)
{
	amount += addAmt;
}

void Balance::removeBalance(int remAmt)
{
	amount -= remAmt;
}

int Balance::getBalance()
{
	return amount;
}
