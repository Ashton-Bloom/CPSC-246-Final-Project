#include "pch.h"
#include "Hand.h"
#include <iostream>
#include <algorithm>

using namespace std;

Hand::Hand()
{
	handValue = 0;
}

Hand::Hand(Deck* d)
{
	cardDeck = d;
}


Hand::~Hand()
{
}

void Hand::addCard(Card card)
{
	cardsInHand.push_back(card);
}

void Hand::drawCard()
{
	cardsInHand.push_back(cardDeck->getTopCard());
}

int Hand::getCardVal(int index)
{
	return cardsInHand[index].getCardVal();
}

Card Hand::getCard(int index)
{
	return cardsInHand[index];
}

string Hand::getCardSuit(int index)
{
	return cardsInHand[index].getSuit();
}

void Hand::PrintCards()
{
	for (unsigned int i = 0; i < cardsInHand.size(); i++)
	{
		if (cardsInHand[i].getCardVal() == 14)
		{
			cout << "A:" << cardsInHand[i].getSuit() << endl;
		}
		else if (cardsInHand[i].getCardVal() == 13)
		{
			cout << "K:" << cardsInHand[i].getSuit() << endl;
		}
		else if (cardsInHand[i].getCardVal() == 12)
		{
			cout << "Q:" << cardsInHand[i].getSuit() << endl;
		}
		else if (cardsInHand[i].getCardVal() == 11)
		{
			cout << "J:" << cardsInHand[i].getSuit() << endl;
		}
		else
		cout << cardsInHand[i].getCardVal() << ":" << cardsInHand[i].getSuit() << endl;
	}
}

void Hand::PrintPlayerHand()
{
	for (unsigned int i = 0; i < 2; i++)
	{
		if (cardsInHand[i].getCardVal() == 14)
		{
			cout << "A:" << cardsInHand[i].getSuit() << endl;
		}
		else if (cardsInHand[i].getCardVal() == 13)
		{
			cout << "K:" << cardsInHand[i].getSuit() << endl;
		}
		else if (cardsInHand[i].getCardVal() == 12)
		{
			cout << "Q:" << cardsInHand[i].getSuit() << endl;
		}
		else if (cardsInHand[i].getCardVal() == 11)
		{
			cout << "J:" << cardsInHand[i].getSuit() << endl;
		}
		else
			cout << cardsInHand[i].getCardVal() << ":" << cardsInHand[i].getSuit() << endl;
	}
}

void Hand::clearHand()
{
	cardsInHand.clear();
}

int Hand::calcHandVal()
{
	vector<int> cardVals;
	vector<string> cardSuits;
	vector<string> sortedCardSuits;
	vector<int> sortedCardVals;
	vector<int> flushCards;
	vector<int> sfFlushCards;
	vector<int> straightDups;
	vector<int> rfFlushCards;

	int handValue = 0;					//1 for High Card - 10 for Royal
	int count = 0;

	int highCard = 0;

	int Pair = 0;

	int firstPair = 0;
	int secondPair = 0;
	int thirdPair = 0;
	int highPair = 0;
	int lowPair = 0;

	int threeOfKind = 0;

	int straightHighCard = 0;
	int x = 0;

	int fHousePair = 0;
	int fHouseThree = 0;

	int fourOfKind = 0;

	string flushSuit = " ";
	int flushHighCard = 0;

	int sfStraightHighCard = 0;
	string sfFlushSuit = " ";
	int sfFlushHighCard = 0;

	int rfStraightHighCard = 0;
	string rfFlushSuit = " ";
	int rfFlushHighCard = 0;

	bool isHighCard, isPair, isTwoPair, isThreeOfKind, isStraight, isFlush, isFullHouse, isFourOfKind, isStraightFlush, isRoyal;
	isHighCard = false;
	isPair = false;
	isTwoPair = false;
	isThreeOfKind = false;
	isStraight = false;
	isFlush = false;
	isFullHouse = false;
	isFourOfKind = false;
	isStraightFlush = false;
	isRoyal = false;

	for (int i = 0; i < cardsInHand.size(); i++)
	{
		cardVals.push_back(cardsInHand[i].getCardVal());
		sortedCardVals.push_back(cardsInHand[i].getCardVal());
		cardSuits.push_back(cardsInHand[i].getSuit());
		sortedCardSuits.push_back(cardsInHand[i].getSuit());
		straightDups.push_back(cardsInHand[i].getCardVal());
	}

	sort(sortedCardVals.begin(), sortedCardVals.end());
	sort(sortedCardSuits.begin(), sortedCardSuits.end());
	sort(straightDups.begin(), straightDups.end());

	if (isHighCard == false)
	{
		//highCard = *max_element(sortedCardVals.begin(), sortedCardVals.end());
		highCard = sortedCardVals[6];
		handValue = 1;
		isHighCard = true;
	}

	if (isPair == false)
	{
		for (int i = 0; i < 6; i++)
		{
			if (sortedCardVals[i] == sortedCardVals[i + 1])
			{
				Pair = sortedCardVals[i];
				handValue = 2;
				isPair = true;
			}
		}
	}

	if (isTwoPair == false)
	{
		for (int i = 0; i < 6; i++)
		{
			if (sortedCardVals[i] == sortedCardVals[i + 1])
			{

				switch (count)
				{
				case 0:
					firstPair = sortedCardVals[i];
					count++;
					break;
				case 1:
					if (firstPair != sortedCardVals[i])
					{
						secondPair = sortedCardVals[i];
						count++;
					}
					break;
				case 2:
					if (secondPair != sortedCardVals[i])
					{
						thirdPair = sortedCardVals[i];
						count++;
					}
					break;
				}
			}
		}

		if (firstPair != 0 && secondPair != 0 && thirdPair == 0)
		{
			isTwoPair = true;
			handValue = 3;
			lowPair = firstPair;		//firstpair will be the smaller of the two pairs
			highPair = secondPair;		//secondpair will be the greater of the two pairs
		}
		if (firstPair != 0 && secondPair != 0 && thirdPair != 0)
		{
			isTwoPair = true;
			handValue = 3;
			lowPair = secondPair;		//secondpair will be the smaller of the two pairs
			highPair = thirdPair;		//thirdpair will be the greater of the two pairs
		}
		count = 0;
	}

	if (isThreeOfKind == false)
	{
		for (int i = 0; i < 5; i++)
		{
			if (sortedCardVals[i] == sortedCardVals[i + 1] && sortedCardVals[i] == sortedCardVals[i + 2])
			{
				threeOfKind = sortedCardVals[i];
				handValue = 4;
				isThreeOfKind = true;
			}
		}
	}

	if (isStraight == false)		//will give the high card of the straight. so to find what the straight is, just subtract 4 to find the lower bound
	{
		straightDups.erase(unique(straightDups.begin(), straightDups.end()), straightDups.end());

		switch (straightDups.size())
		{
		case 5:
		{
			if (straightDups[x] == straightDups[x + 1] - 1 && straightDups[x] == straightDups[x + 2] - 2 && straightDups[x] == straightDups[x + 3] - 3 && straightDups[x] == straightDups[x + 4] - 4)
			{
				straightHighCard = straightDups[x + 4];
				handValue = 5;
				isStraight = true;
			}
			break;
		}

		case 6:
		{
			for (int i = 0; i < 2; i++)
			{
				if (straightDups[i] == straightDups[i + 1] - 1 && straightDups[i] == straightDups[i + 2] - 2 && straightDups[i] == straightDups[i + 3] - 3 && straightDups[i] == straightDups[i + 4] - 4)
				{
					straightHighCard = straightDups[i + 4];
					handValue = 5;
					isStraight = true;
				}
			}
			break;
		}

		case 7:
		{
			for (int i = 0; i < 3; i++)
			{
				if (straightDups[i] == straightDups[i + 1] - 1 && straightDups[i] == straightDups[i + 2] - 2 && straightDups[i] == straightDups[i + 3] - 3 && straightDups[i] == straightDups[i + 4] - 4)
				{
					straightHighCard = straightDups[i + 4];
					handValue = 5;
					isStraight = true;
				}
			}
			break;
		}
		}
	}

	if (isFlush == false)
	{
		for (int i = 0; i < 3; i++)
		{
			if (sortedCardSuits[i] == sortedCardSuits[i + 1] && sortedCardSuits[i] == sortedCardSuits[i + 2] && sortedCardSuits[i] == sortedCardSuits[i + 3] && sortedCardSuits[i] == sortedCardSuits[i + 4])
			{
				flushSuit = cardSuits[i];
			}
		}
		if (flushSuit != " ")
		{
			for (int i = 0; i < 7; i++)
			{
				if (cardsInHand[i].getSuit() == flushSuit)
				{
					flushCards.push_back(cardsInHand[i].getCardVal());
				}
			}

			sort(flushCards.begin(), flushCards.end());

			flushHighCard = flushCards.back();
			handValue = 6;
			isFlush = true;
		}
	}

	if (isFullHouse == false)
	{
		for (int i = 0; i < 5; i++)		//finds the best three of kind
		{
			if (sortedCardVals[i] == sortedCardVals[i + 1] && sortedCardVals[i] == sortedCardVals[i + 2])
			{
				fHouseThree = sortedCardVals[i];
			}
		}
		if (fHouseThree != 0)			//finds the best pair that isn't the same value of the three of kind
		{
			for (int i = 0; i < 6; i++)
			{
				if (sortedCardVals[i] == sortedCardVals[i + 1])
				{
					if (fHouseThree != sortedCardVals[i])
					{
						fHousePair = sortedCardVals[i];
					}
				}
			}
		}
		if (fHouseThree != 0 && fHousePair != 0)
		{
			handValue = 7;
			isFullHouse = true;
			fHousePair = fHousePair;
			fHouseThree = fHouseThree;
		}
	}

	if (isFourOfKind == false)
	{
		for (int i = 0; i < 4; i++)
		{
			if (sortedCardVals[i] == sortedCardVals[i + 1] && sortedCardVals[i] == sortedCardVals[i + 2] && sortedCardVals[i] == sortedCardVals[i + 3])
			{
				fourOfKind = sortedCardVals[i];
				handValue = 8;
				isFourOfKind = true;
			}
		}
	}

	if (isStraightFlush == false)
	{
		count = 0;
		straightDups.erase(unique(straightDups.begin(), straightDups.end()), straightDups.end());

		switch (straightDups.size())
		{
		case 5:
		{
			if (straightDups[x] == straightDups[x + 1] - 1 && straightDups[x] == straightDups[x + 2] - 2 && straightDups[x] == straightDups[x + 3] - 3 && straightDups[x] == straightDups[x + 4] - 4)
			{
				sfStraightHighCard = straightDups[x + 4];
			}
			break;
		}

		case 6:
		{
			for (int i = 0; i < 2; i++)
			{
				if (straightDups[i] == straightDups[i + 1] - 1 && straightDups[i] == straightDups[i + 2] - 2 && straightDups[i] == straightDups[i + 3] - 3 && straightDups[i] == straightDups[i + 4] - 4)
				{
					sfStraightHighCard = straightDups[i + 4];
				}
			}
			break;
		}

		case 7:
		{
			for (int i = 0; i < 3; i++)
			{
				if (straightDups[i] == straightDups[i + 1] - 1 && straightDups[i] == straightDups[i + 2] - 2 && straightDups[i] == straightDups[i + 3] - 3 && straightDups[i] == straightDups[i + 4] - 4)
				{
					sfStraightHighCard = straightDups[i + 4];
				}
			}
			break;
		}
		}
		if (sfStraightHighCard != 0)
		{
			for (int i = 0; i < 3; i++)
			{
				if (sortedCardSuits[i] == sortedCardSuits[i + 1] && sortedCardSuits[i] == sortedCardSuits[i + 2] && sortedCardSuits[i] == sortedCardSuits[i + 3] && sortedCardSuits[i] == sortedCardSuits[i + 4])
				{
					sfFlushSuit = sortedCardSuits[i];
				}
			}
			if (sfFlushSuit != " ")
			{
				for (int i = 0; i < 7; i++)
				{
					if (cardsInHand[i].getSuit() == sfFlushSuit)
					{
						sfFlushCards.push_back(cardsInHand[i].getCardVal());
					}
				}

				sort(sfFlushCards.begin(), sfFlushCards.end());

				sfFlushHighCard = sfFlushCards.back();

				for (int i = 0; i == straightDups.size(); i++)
				{
					for (int j = 0; j == sfFlushCards.size(); j++)
					{
						if (straightDups[i] == sfFlushCards[j])
						{
							count++;
						}
					}
				}
			}
			switch (count)
			{
			case 5:
			{
				handValue = 9;
				isStraightFlush = true;
				break;
			}
			case 6:
			{
				handValue = 9;
				isStraightFlush = true;
				break;
			}
			case 7:
			{
				handValue = 9;
				isStraightFlush = true;
				break;
			}
			}
		}
	}

	if (isRoyal == false)
	{
		count = 0;
		straightDups.erase(unique(straightDups.begin(), straightDups.end()), straightDups.end());

		switch (straightDups.size())
		{
		case 5:
		{
			if (straightDups[x] == straightDups[x + 1] - 1 && straightDups[x] == straightDups[x + 2] - 2 && straightDups[x] == straightDups[x + 3] - 3 && straightDups[x] == straightDups[x + 4] - 4)
			{
				rfStraightHighCard = straightDups[x + 4];
			}
			break;
		}

		case 6:
		{
			for (int i = 0; i < 2; i++)
			{
				if (straightDups[i] == straightDups[i + 1] - 1 && straightDups[i] == straightDups[i + 2] - 2 && straightDups[i] == straightDups[i + 3] - 3 && straightDups[i] == straightDups[i + 4] - 4)
				{
					rfStraightHighCard = straightDups[i + 4];
				}
			}
			break;
		}

		case 7:
		{
			for (int i = 0; i < 3; i++)
			{
				if (straightDups[i] == straightDups[i + 1] - 1 && straightDups[i] == straightDups[i + 2] - 2 && straightDups[i] == straightDups[i + 3] - 3 && straightDups[i] == straightDups[i + 4] - 4)
				{
					rfStraightHighCard = straightDups[i + 4];
				}
			}
			break;
		}
		}
		if (rfStraightHighCard != 0)
		{
			for (int i = 0; i < 3; i++)
			{
				if (sortedCardSuits[i] == sortedCardSuits[i + 1] && sortedCardSuits[i] == sortedCardSuits[i + 2] && sortedCardSuits[i] == sortedCardSuits[i + 3] && sortedCardSuits[i] == sortedCardSuits[i + 4])
				{
					rfFlushSuit = sortedCardSuits[i];
				}
			}
			if (rfFlushSuit != " ")
			{
				for (int i = 0; i < 7; i++)
				{
					if (cardsInHand[i].getSuit() == rfFlushSuit)
					{
						rfFlushCards.push_back(cardsInHand[i].getCardVal());
					}
				}

				sort(rfFlushCards.begin(), rfFlushCards.end());

				rfFlushHighCard = rfFlushCards.back();

				for (int i = 0; i == straightDups.size(); i++)
				{
					for (int j = 0; j == rfFlushCards.size(); j++)
					{
						if (straightDups[i] == rfFlushCards[j])
						{
							count++;
						}
					}
				}
			}
			switch (count)
			{
			case 5:
			{
				if (rfFlushHighCard == 14 && rfStraightHighCard == 14)
				{
					handValue = 10;
					isRoyal = true;
					break;
				}
			}
			case 6:
			{
				if (rfFlushHighCard == 14 && rfStraightHighCard == 14)
				{
					handValue = 10;
					isRoyal = true;
					break;
				}
			}
			case 7:
			{
				if (rfFlushHighCard == 14 && rfStraightHighCard == 14)
				{
					handValue = 10;
					isRoyal = true;
					break;
				}
			}
			}
		}
	}

	return handValue;
}