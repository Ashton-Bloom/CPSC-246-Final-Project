#pragma once
#include <string>
#include <stdlib.h>
#include <vector>
#include "Card.h"
#include "Deck.h"
using namespace std;

class Hand
{
private:
	Deck* cardDeck;
	vector<Card> cardsInHand;
	static const int STARTINGCARD = 2;
	int handValue;

public:
	Hand();
	Hand(Deck* d);
	~Hand();

	void addCard(Card);
	void drawCard();
	int getCardVal(int index);
	void PrintPlayerHand();
	void PrintCards();
	Card getCard(int index);
	string getCardSuit(int index);
	int calcHandVal();
	void clearHand();
};
