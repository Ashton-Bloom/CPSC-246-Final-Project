#pragma once
#include <string>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include "Card.h"

using namespace std;

class Deck
{
private:
	static const int DECKSIZE = 52;
	static const int SUITS = 4;
	static const int VALUES = 13;
	vector<Card>cardDeck;
	static Deck* instance;

public:
	Deck();
	~Deck();

	void resetDeck();
	static Deck* getInstance();
	Card getTopCard();
	int getCardsLeft();
	void shuffleDeck();
	void printDeck();

};

